#!bin/bash
c++ det.cpp -o det
