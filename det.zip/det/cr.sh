#!bin/bash
c++ det.cpp -o det
./det 1 > det1.txt
./det 2 > det2.txt
./det 3 > det3.txt
./det 4 > det4.txt
