#include <iostream>

double A[10][10];

void imprimir(int *s, int N)
{
	for(int k=0; k<N; ++k)
		std::cout << s[k] << " ";
	std::cout << std::endl;
}

int signo(int *s, int N)
{
	int c=1;
	for(int i=0; i<N; ++i)
		for(int j=i+1; j<N; ++j)
			if(s[i]>s[j])
				c=-c;
	return c;
}

void sum(int N, int *s, double &det)
{
	double p = signo(s, N);
	for(int k=0; k<N; ++k)
		p *= A[k][s[k]];
	det+=p;
}

void permutacion(int n, int *s, int N, double &det)
{
	if(!n)
		sum(N, s, det);
	else
		for(int k=n-1; k>=0; --k)
		{
			int t=s[n-1];
			s[n-1]=s[k];
			s[k]=t;
			permutacion(n-1, s, N, det);
			t=s[n-1];
			s[n-1]=s[k];
			s[k]=t;
		}
}


int main(int argn, char **args)
{
	int N;
	N = atoi(args[1]);


	int *s = new int [N];
	for(int k=0; k<N; ++k)
		s[k]=k+1;

	double det = 0.0;
	permutacion(N,s,N, det);
	return 0;
}
